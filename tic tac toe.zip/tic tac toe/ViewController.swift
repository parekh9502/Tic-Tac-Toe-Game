//
//  ViewController.swift
//  tic tac toe
//
//  Created by Pritesh Parekh on 08/01/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//
import UIKit

class ViewController: UIViewController {
    var change = 1
    var gamestate = [0,0,0,0,0,0,0,0,0]
    
    let winning = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]
    
    var gameactive = true
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var board: UIImageView!
    
    @IBAction func buttons(_ sender: Any) {
      if gamestate[(sender as AnyObject).tag - 1] == 0 && gameactive == true
      {
        gamestate[(sender as AnyObject).tag - 1] = change
        
        if (change == 1)
        {
            (sender as AnyObject).setImage(UIImage(named : "Cross.png"), for: UIControlState())
            change = 2
        }
        else
        {
            (sender as AnyObject).setImage(UIImage(named : "Nought.png"), for: UIControlState())
            change = 1
        }
        }
        for combination in winning {
            if  gamestate [combination[0]] != 0 && gamestate[combination[0]] == gamestate[combination[1]] && gamestate[combination[1]] == gamestate[combination[2]]
            {
               gameactive = false
            
            if gamestate[combination[0]] == 1
            {
                label.text = " CROSS HAS WON!"
                } else
            {
                label.text = " NOUGHT HAS WON!"
                }
                
                PlayAgainBtn.isHidden = false
                label.isHidden = false
                
                
            }}
        
        gameactive = false
        
        for i in gamestate
        {
          if  i == 0
          {
              gameactive = true
             break
            }
        }
        
        if gameactive == false {
            label.text = " IT WAS A DRAW!"
            PlayAgainBtn.isHidden = false
            label.isHidden = false
        }
        
 
        
        
        
        
        
        
}
    
    @IBOutlet weak var PlayAgainBtn: UIButton!
    @IBAction func PlayAgain(_ sender: Any) {
        
        gameactive = true
        change = 1
        gamestate = [0,0,0,0,0,0,0,0,0]
        
        PlayAgainBtn.isHidden = true
        label.isHidden = true
        
        for i in 1...9
        {
            let button = view.viewWithTag(i) as? UIButton
            button?.setImage(nil, for: UIControlState())
        }
        
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

